import os

print("Current Working Directory:", os.getcwd())

# Load motif scoring matrix from motifCode.txt
base_idx = {'A': 0, 'T': 1, 'C': 2, 'G': 3}
motif = [
    [0.5, 0.5, 0.5, 0.5, 0, 0, 0, 0, 0, 2, -99, -99, 0.5],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, -99, 2, -99, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, -99, -99, -99, 0],
    [0.5, 0.5, 0.5, 0.5, 0, 0, 0, 0, 0, 0.5, -99, 2, 0]
]

def read_fasta(file_path):
    """Reads a FASTA file and returns a dictionary of sequences."""
    sequences = {}
    with open(file_path, 'r') as f:
        current_contig = ""
        current_sequence = ""
        for line in f:
            if line.startswith('>'):
                if current_contig:
                    sequences[current_contig] = current_sequence
                current_contig = line.strip().replace('>', '').split()[0]  # Ensure correct naming
                current_sequence = ""
            else:
                current_sequence += line.strip()
        if current_contig:
            sequences[current_contig] = current_sequence
    return sequences


def scanSeq(sequence, contig):
    """Finds ORFs using motif scoring and valid start-stop codon pairing."""
    start_codons = ['ATG', 'GTG']
    stop_codons = ['TAA', 'TAG', 'TGA']
    orfs = []
    start_positions = []
    lengths = []

    i = 0
    while i <= len(sequence) - 13:
        window = sequence[i:i + 13]
        motif_score = scoreMotif(window)

        # Ensure the 13bp window has a high motif score and contains a valid start codon
        if motif_score > 7.25 and window[9:12] in start_codons:
            start_pos = i + 9
            for j in range(start_pos + 3, len(sequence) - 2, 3):
                if sequence[j:j + 3] in stop_codons:
                    orf_seq = sequence[start_pos:j + 3]
                    if len(orf_seq) >= 60:  # Ensure ORF meets minimum length criteria
                        orfs.append(orf_seq)
                        start_positions.append(start_pos + 1)
                        lengths.append(len(orf_seq))
                    break  # Stop at the first encountered stop codon
        i += 1  # Move to next position in the sequence

    return orfs, start_positions, lengths


def scoreMotif(sequence):
    """Scores a 13bp sequence using the motif matrix."""
    score = 0
    for i, nucleotide in enumerate(sequence):
        if nucleotide in base_idx and i < len(motif[0]):
            score += motif[base_idx[nucleotide]][i]
    return score


def identify_ORFs(input_file, output_file):
    """Identifies ORFs from the input FASTA file and writes them to an output FASTA file."""
    sequences = read_fasta(input_file)

    with open(output_file, 'w') as f:
        for contig, seq in sequences.items():
            orfs, start_positions, lengths = scanSeq(seq, contig)

            for i in range(len(orfs)):
                header = f"> {contig}_ORF{i + 1}|Length {lengths[i]}|at position {start_positions[i]}"
                f.write(header + "\n")
                f.write(orfs[i] + "\n")

                # Print output to console for debugging
                print(header)
                print(orfs[i] + "\n")


# Run ORF identification
identify_ORFs("spaceSeq.fa", "output.fa")
