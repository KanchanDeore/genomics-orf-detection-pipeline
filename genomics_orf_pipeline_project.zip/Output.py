import random
import matplotlib.pyplot as plt


print("Matplotlib is installed successfully!")

# Generate random sequences
def generate_random_sequences(num_sequences, length):
    """Generates random DNA sequences of given length."""
    bases = ['A', 'T', 'G', 'C']
    return [''.join(random.choices(bases, k=length)) for _ in range(num_sequences)]


# Scan sequence for ORFs
def scan_orfs(sequence):
    """Finds ORFs in a sequence starting with ATG and ending with a stop codon."""
    start_codon = "ATG"
    stop_codons = {"TAA", "TAG", "TGA"}  # Use a set for faster lookups
    orf_lengths = []

    for i in range(len(sequence) - 2):
        if sequence[i:i + 3] == start_codon:
            for j in range(i + 3, len(sequence) - 2, 3):
                if sequence[j:j + 3] in stop_codons:
                    orf_lengths.append(j - i + 3)
                    break  # Stop at first encountered stop codon
    return orf_lengths


# Parameters
num_sequences = 10000  # Large sample for better distribution
sequence_length = 150

# Generate sequences once and analyze ORFs
sequences = generate_random_sequences(num_sequences, sequence_length)
all_orf_lengths = []
sequences_with_long_orfs = 0

for seq in sequences:
    orf_lengths = scan_orfs(seq)
    all_orf_lengths.extend(orf_lengths)

    # Count sequences with at least one ORF > 60
    if any(l > 60 for l in orf_lengths):
        sequences_with_long_orfs += 1

# Compute fraction of sequences with ORFs > 60
fraction = sequences_with_long_orfs / num_sequences

# Plot histogram
plt.figure(figsize=(8, 5))
plt.hist(all_orf_lengths, bins=range(0, max(all_orf_lengths) + 10, 10), edgecolor='black', alpha=0.7)
plt.xlabel("ORF Lengths")
plt.ylabel("Frequency (log scale)")
plt.title("Distribution of ORF Lengths in Random Sequences")
plt.yscale("log")  # Log scale for better visualization of rare long ORFs
plt.show()

# Output results
print(f"Total sequences analyzed: {num_sequences}")
print(f"Total ORFs found: {len(all_orf_lengths)}")
print(f"Fraction of sequences with ORFs > 60bp: {fraction:.4f}")
