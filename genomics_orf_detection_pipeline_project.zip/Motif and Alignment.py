import random
import os
print("Current Working Directory:", os.getcwd())


def identify_ORFs(input_file, output_file):
    """Identifies ORFs and writes them to an output FASTA file."""
    sequences = {}
    with open(input_file, 'r') as f:
        current_contig = ""
        current_sequence = ""
        for line in f:
            if line.startswith('>'):
                if current_contig:
                    sequences[current_contig] = current_sequence
                current_contig = line.strip().replace('>', '').split()[0]  # Ensure correct naming
                current_sequence = ""
            else:
                current_sequence += line.strip()
        if current_contig:
            sequences[current_contig] = current_sequence

    with open(output_file, 'w') as f:
        for contig, seq in sequences.items():
            orfs, start_positions, lengths = scanSeq(seq, contig)
            for i in range(len(orfs)):
                f.write(f"> {contig}_ORF{i + 1}|Length {lengths[i]}|at position {start_positions[i]}\n")
                f.write(f"{orfs[i]}\n")
                print(f"> {contig}_ORF{i + 1}|Length {lengths[i]}|at position {start_positions[i]}")
                print(orfs[i])


# Load motif scoring matrix from motifCode.txt
base_idx = {'A': 0, 'T': 1, 'C': 2, 'G': 3}
motif = [[.5, .5, .5, .5, 0, 0, 0, 0, 0, 2, -99, -99, .5],
         [0, 0, 0, 0, 0, 0, 0, 0, 0, -99, 2, -99, 0],
         [0, 0, 0, 0, 0, 0, 0, 0, 0, -99, -99, -99, 0],
         [.5, .5, .5, .5, 0, 0, 0, 0, 0, .5, -99, 2, 0]]


def scanSeq(sequence, contig):
    """Finds ALL ORFs in a sequence using a sliding 13bp window and returns sequences, start positions, and lengths."""
    start_codons = ['ATG', 'GTG']
    stop_codons = ['TAA', 'TAG', 'TGA']
    orfs = []
    start_positions = []
    lengths = []


    i = 0
    while i <= len(sequence) - 13:
        window = sequence[i:i + 13]
        motif_score = scoreMotif(window)
        if motif_score > 7.25 and window[9:12] in start_codons:
            start_pos = i + 9
            for j in range(start_pos + 3, len(sequence) - 2, 3):
                if sequence[j:j + 3] in stop_codons:
                    orf_seq = sequence[start_pos:j + 3]
                    if len(orf_seq) >= 60:
                        orfs.append(orf_seq)
                        start_positions.append(start_pos + 1)
                        lengths.append(len(orf_seq))
                    break
        i += 1  # Continue checking the next 13bp window
    return orfs, start_positions, lengths


def scoreMotif(sequence):
    """Scores a 13bp sequence using the motif matrix."""
    score = 0
    for i, nucleotide in enumerate(sequence):
        if nucleotide in base_idx and i < len(motif[0]):
            score += motif[base_idx[nucleotide]][i]
    return score


# Run ORF identification
identify_ORFs("spaceSeq.fa", "output.fa")

