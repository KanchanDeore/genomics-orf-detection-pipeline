# 🧬 Genomics from Scratch: Discovering Hidden ORFs in DNA

## 👋 Welcome, Curious Biologist or Coder!

This repository is designed to help **anyone**, even if you're new to genomics or coding, understand how scientists find **genes hidden inside DNA**. This project was created as part of my graduate coursework in **BINF 6400 – Genomics** at Northeastern University, and I’ve broken it down so you can learn while exploring.

---

## 🧠 What's the Big Idea?

DNA is like a giant book written with just four letters: `A`, `T`, `C`, and `G`. But not every combination of these letters means something — only certain patterns, called **genes** or **open reading frames (ORFs)**, tell cells what proteins to make.

**Your mission here:**  
📌 Generate random DNA sequences  
📌 Search for meaningful "gene-like" regions (ORFs)  
📌 Score these regions using a biological pattern (motif)  
📌 Visualize how often useful ORFs appear by chance  

---

## 🛠️ What Did I Use?

| Tool | Why I Used It |
|------|---------------|
| `Python` | To automate and analyze everything |
| `FASTA` | A simple format to store DNA sequences |
| `Matplotlib` | To create graphs showing ORF patterns |
| `Biological motifs` | To find interesting parts of DNA (like fingerprints of real genes) |

---

## 🧬 Step-by-Step Explanation (From Scratch!)

### 🧪 Step 1: Create Random DNA

Using `generateRandomSeq.py`, I created **random DNA reads** – these are short, fake DNA snippets that mimic what you might get from a sequencer. We want to know if "real-looking" genes could appear by pure chance.

Each DNA read looks like this:
```
>sequence 1
AGCTTACGGATGCACTTAAG
```

### 🔍 Step 2: Define What a Gene Looks Like (Motifs!)

Real genes usually:
- Start with **start codons** like `ATG` or `GTG`
- End with **stop codons** like `TAA`, `TAG`, or `TGA`
- Have recognizable patterns inside — we use a **motif scoring matrix** to check for that!

This is where `Motif and Alignment.py` comes in. It checks every 13-letter window in your sequence to see if it matches the known biological motif.

### 🧬 Step 3: Scan for ORFs

ORFs are stretches of DNA that look like genes. Using `ORFs.py`, I scanned each sequence to:
- Start at a valid codon
- Continue with a decent score (based on our motif)
- End cleanly with a stop codon

These ORFs are written into `output.fa`, which looks like this:
```
>orf_12 score=43.7
ATGGGCTACCTGACATGTAAGTTAG
```

### 📊 Step 4: Simulate & Visualize

Now, the **fun part**. Using `Output.py`, I ran this experiment **10,000 times** to answer this question:

> "How often do long ORFs show up by chance in fake DNA?"

Then, I plotted the **distribution of ORF lengths**. The result?  
- Long ORFs are **rare**  
- Most random sequences have **short** or **no ORFs**  
- Real genes likely have evolved to be *non-random*

📷 See the result in `Score Distribution.png`.

---

## 📁 What's Inside This Project

| File | What It Does |
|------|--------------|
| `generateRandomSeq.py` | Generates short random DNA reads |
| `Motif and Alignment.py` | Scores sequences using a motif and finds ORFs |
| `ORFs.py` | Cleaner script for motif-based ORF extraction |
| `Output.py` | Runs large simulations and plots ORF distributions |
| `spaceSeq.fa` | Input sequence file |
| `random_sequences.fasta` | Generated DNA reads |
| `output.fa` | Final list of predicted ORFs |
| `Score Distribution.png` | Graph of how many ORFs are found |

---

## 🎓 What Can You Learn from This?

- 🧬 How genes are found in raw DNA sequences
- 🧮 How scoring matrices help detect meaningful motifs
- 🐍 How Python can automate real bioinformatics work
- 📉 Why simulation is powerful for hypothesis testing

---

## 🙋‍♀️ Author

**Kanchan Deore**  
MS in Bioinformatics, Northeastern University  
📧 Email: deore.k@northeastern.edu  
🔗 LinkedIn: [KanchanDeore](https://www.linkedin.com)

---

## 💬 Final Thoughts

> “DNA doesn’t come with highlighters — this project builds one.”  
Use this project to understand how genes are discovered, even in randomness, and how computer programs help decode the very blueprint of life.

