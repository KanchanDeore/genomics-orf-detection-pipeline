import random
l = 20 #read length
k = 4
bases = ["A","T","C","G"]
def generateReads(l,k): #prints k reads of length l
    
    for i in range(k):
        seq = ""
        for j in range(l):
            seq += bases[random.randint(0,3)]
        print(">sequence " + str(i+1))
        print(seq)
generateReads(l,k)